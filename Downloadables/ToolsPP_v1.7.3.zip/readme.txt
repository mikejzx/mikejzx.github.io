----------------------------------------TOOLS++-------------------------------------------

Tools++ was developed by Michael �. If you think have a better name for it, e-mail me !
� Copyright 2018 All Rights Reserved.

For information about this program, or for my e-mail, please visit my website:
https://mikejzx.github.io

The original download link for this software is here:
https://mikejzx.github.io/Files/ToolsPP_v1.7.3.zip

------------------------------------------------------------------------------------------

You are free to distribute this software under the following conditions:
1.) The software MUST be original, and not modified in any way or form.
2.) You MUST NOT charge any money for this software. It is free-ware !
3.) You MUST include this readme. It MUST also be un-edited.
4.) The person(s)/group you are distributing my software to MUST have the 
	link to my website, in some clear way or form.

5.) (OPTIONAL) Send me an e-mail letting me know that you distributed Tools++ ;)

------------------------------------------------------------------------------------------

Version: 1.7.3
Released: 14.08.2018
This readme last edited: 14.08.2018
Program last edited: 14.08.2018

------------------------------------------------------------------------------------------

Proudly made in Australia !